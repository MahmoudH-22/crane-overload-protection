# Crane Overload: laser-cut files

The structure is cut from **7 mm MDF**, nested on two 1200 × 600 sheets. The control panel is cut from **3 mm acrylic**. Every part matches the 3D model (`crane-structure-3d.html`):
- tab-and-slot base box with the electronics bay inside
- finger-jointed mast and arm
- dowelled block stacks
- keyed motor plate
- tabbed brace

## Files
| Folder / file | What it is |
|---|---|
| `sheets/mdf7_sheet_1_1200x600.dxf`, `mdf7_sheet_2_1200x600.dxf` | All 68 MDF pieces nested, ready to cut |
| `parts_mdf_7mm/` | Each MDF part alone; the file name ends with the quantity (`_x2` = cut 2) |
| `parts_acrylic_3mm/PANEL_control_panel_200x120_acrylic3mm_x1.dxf` | Control panel, with engraved legends |
| `preview/` | Pictures of the sheets, the panel and the team plate |
| `cut_list.csv` | Every part with size, quantity and where it goes |

## Layers
| Layer | Colour | Do |
|---|---|---|
| `CUT` | red | Cut through |
| `ENGRAVE` | blue | Engrave (fill / scan). All text is converted to outlines, so no font is needed |
| `LABELS` | green | Small part codes for sorting. Light engrave, or switch the layer off |
| `SHEET` | grey | Sheet border, **do not cut** |

## Team plate
**P03F, the front long rib of the base**, carries the engraving, centred under the control panel:

> **CRANE OVERLOAD**
> Mahmoud Hisham 2400844 · Ziad Hany 2301401 · Abdulrahman Mohamed 2400544 · Ahmed Hany 2400311

The engraved face goes **outside**. This rib has no part code engraved on it, so the outside face stays clean.

## Notes for the laser shop
- Units are mm, 1:1, with **no kerf compensation**. Slots and notches are drawn exactly **7.0 mm** wide.
  - Measure the real MDF thickness first.
  - If it is not 7.0 mm, or the joints are loose after a test cut, ask the shop to offset the slots, or tell me the measured thickness and I'll regenerate the files.
- 7 mm MDF usually needs a 60–100 W laser or 2 passes.
- Cut a **test piece first**: one P11 block and the end of a P08 finger strip, to check that the tabs and fingers fit.

## Parts (7 mm MDF)
| Code | Part | Qty | Size incl. tabs (mm) | Where it goes |
|---|---|---|---|---|
| P01 | Base top plate | 1 | 450.0 x 300.0 | Top of the base: rib slots, mast socket, 180 × 100 control panel opening (+4 × M3 holes), Ø20 cable grommet. |
| P02 | Base bottom plate | 1 | 450.0 x 300.0 | Bottom of the base: rib, socket-block and mast tab slots, 8 standoff holes, 3 vents under the L298N, 4 feet holes. |
| P03F | Long rib FRONT (team plate) | 1 | 450.0 x 100.0 | Front long wall of the base (z = +136…143), under the control panel. The ENGRAVED face goes OUTSIDE. |
| P03B | Long rib back | 1 | 450.0 x 100.0 | Back long wall of the base (z = -143…-136). |
| P04B | End rib back (connectors) | 1 | 286.0 x 100.0 | Back wall of the base (x = -293): DC jack Ø8, USB 12 × 11, 3 vents, divider slot. |
| P04F | End rib front | 1 | 286.0 x 100.0 | Front wall of the base (x = +136). |
| P05A | Inner rib back (divider slot) | 1 | 286.0 x 100.0 | Behind the mast socket (x = -32…-25). |
| P05B | Inner rib front | 1 | 286.0 x 100.0 | In front of the mast socket (x = 25…32). |
| P06 | Socket block | 2 | 64.0 x 93.0 | Closes the mast socket (z = ±25…32). |
| P19 | Divider rib | 1 | 268.0 x 100.0 | Splits the electronics bay from the counterweight compartment (z = 0). |
| P07F | Mast front wall | 1 | 50.0 x 568.0 | Faces the arm: 5 notches each edge, bottom tab, motor-plate bolt holes, key slot, brace slot. |
| P07B | Mast back wall | 1 | 50.0 x 568.0 | Back wall: 5 notches each edge, bottom tab, motor-plate bolt holes. |
| P08 | Mast side wall | 2 | 50.0 x 568.0 | 5 fingers each edge, bottom tab off-centre (toward the back), gusset and brace bolt holes. |
| P09T | Arm top wall | 1 | 465.0 x 50.0 | 5 notches each edge; pulley and IR bracket bolt holes. |
| P09B | Arm bottom wall | 1 | 465.0 x 50.0 | Same + brace slot + 2 dowel holes for the mast-top pins. |
| P10 | Arm side wall | 2 | 465.0 x 50.0 | 5 fingers each edge; gusset and brace bolt holes. |
| P11 | Block 36 × 36 | 34 | 36.0 x 36.0 | Stacks of 5 on 2 dowels: mast 4 stacks, arm 2 stacks; 2 end caps; 2 spares. |
| P12 | Gusset plate | 2 | 150.0 x 150.0 | Both sides of the mast–arm joint: 2 dowels + 2 M4 bolts. |
| P13 | Brace strip | 2 | 318.0 x 46.9 | Glue 2 strips face to face; tabs into the mast and arm slots; M4 cross-bolt through each tab. |
| P14A | Motor plate layer 1 (key slot) | 1 | 200.0 x 90.0 | Against the mast front wall. |
| P14B | Motor plate layer 2 | 1 | 200.0 x 90.0 | Outer layer; dowels align it to layer 1. |
| P15 | IR sensor plate | 1 | 20.0 x 26.0 | FC-51 screwed through the slot (height adjust). |
| P16 | IR bracket foot | 1 | 20.0 x 20.0 | Glued on P15; 2 × M3 up through the arm. |
| P17 | Tab spacer | 4 | 20.0 x 20.0 | On the brace cross-bolts, each side of each tab. |
| P20 | Ultrasonic holder | 1 | 60.0 x 34.0 | Inside the basket floor: the HC-SR04 transducers push through the 2 holes; also the drill template for the 2 Ø16.5 holes in the basket floor. |
| P18 | Locating key layer | 2 | 20.0 x 10.0 | Glue 2 together (14 thick): through the motor plate into the mast front wall. |
| PANEL | Control panel | 1 | 200 x 120 | Screws over the base panel opening |

## Hardware
| Item | Qty | Use |
|---|---|---|
| Ø6 × 35 beech dowel | 12 | Block stacks (2 per stack). Cut the 2 mast-top ones 12 mm longer, to locate the arm |
| Ø6 × 20 beech dowel | 6 | Gussets (2 each) and motor plate layers (2) |
| M4 × 80 bolt + nylock + washers | 4 | Motor plate (2) and gussets (2), through the box beams |
| M4 × 60 bolt + nylock + washers | 2 | Brace cross-bolts |
| M3 × 60 / M3 × 65 bolts + nuts | 2 + 2 | Pulley U-bracket / IR bracket, up through the arm |
| M3 × 12 screws | 4 | Control panel to the base top plate |
| M3 nylon standoffs 10 mm | 8 | Uno/shield and L298N on the base bottom plate |
| Rubber grommet Ø20 | 1 | Cable entry in the base top plate (5 cables incl. the ultrasonic sensor) |
| Rubber feet | 4 | Base bottom plate |
| PVA wood glue, clamps, sandpaper, primer + paint | – | Glue only after dry-fitting |

## Assembly
Follow **Assembly steps** in the 3D model (14 steps):
1. Base ribs
2. Base top plate
3. Mast box
4. Mast into the base + counterweight
5. Base bottom plate
6. Arm box
7. Gussets
8. Brace
9. Motor plate
10. Hoist
11. Arm tip
12. Rope, load cell and hook
13. Electronics bay
14. Control panel

Dry-fit every stage before gluing: the tabs, fingers and dowels only fit one way.
